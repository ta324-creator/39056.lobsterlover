# Shared helpers for the PROPESA 3D renders (Blender bpy, Cycles).
import bpy, bmesh, math
from mathutils import Vector, Matrix


def limpiar():
    bpy.ops.wm.read_factory_settings(use_empty=True)


def mat(nombre, color, rough=0.35, metal=0.0, coat=0.0, emis=None, alpha=None):
    m = bpy.data.materials.new(nombre)
    m.use_nodes = True
    p = m.node_tree.nodes['Principled BSDF']
    p.inputs['Base Color'].default_value = (*color, 1)
    p.inputs['Roughness'].default_value = rough
    p.inputs['Metallic'].default_value = metal
    if coat:
        p.inputs['Coat Weight'].default_value = coat
        p.inputs['Coat Roughness'].default_value = 0.08
    return m


def hexlin(h):
    h = h.lstrip('#')
    c = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    return tuple(x / 12.92 if x <= 0.04045 else ((x + 0.055) / 1.055) ** 2.4 for x in c)


def objeto(nombre, bm, mats, suave=True, subdiv=0):
    me = bpy.data.meshes.new(nombre)
    bm.to_mesh(me)
    bm.free()
    ob = bpy.data.objects.new(nombre, me)
    bpy.context.collection.objects.link(ob)
    for m in mats:
        me.materials.append(m)
    if suave:
        for f in me.polygons:
            f.use_smooth = True
    if subdiv:
        md = ob.modifiers.new('sub', 'SUBSURF')
        md.levels = md.render_levels = subdiv
    return ob


def loft(bm, anillos, cerrar_ini=False, cerrar_fin=False, mat_fn=None):
    """anillos: list of lists of Vector, all same length, closed loops."""
    vs = [[bm.verts.new(p) for p in a] for a in anillos]
    n = len(anillos[0])
    caras = []
    for i in range(len(vs) - 1):
        for j in range(n):
            f = bm.faces.new((vs[i][j], vs[i][(j + 1) % n], vs[i + 1][(j + 1) % n], vs[i + 1][j]))
            if mat_fn:
                f.material_index = mat_fn(i, j)
            caras.append(f)
    if cerrar_ini:
        c = bm.verts.new(sum((v.co for v in vs[0]), Vector()) / n)
        for j in range(n):
            bm.faces.new((vs[0][(j + 1) % n], vs[0][j], c))
    if cerrar_fin:
        c = bm.verts.new(sum((v.co for v in vs[-1]), Vector()) / n)
        for j in range(n):
            bm.faces.new((vs[-1][j], vs[-1][(j + 1) % n], c))
    return vs


def perfil_ala(n=22, grosor=0.12, comba=0.02):
    """NACA-like closed airfoil, chord 0..1 along +x(LE=0), thickness in z. Returns list of (x,z)."""
    pts = []
    xs = [0.5 * (1 - math.cos(math.pi * i / n)) for i in range(n + 1)]
    def t(x):
        return 5 * grosor * (0.2969 * math.sqrt(x) - 0.126 * x - 0.3516 * x * x + 0.2843 * x ** 3 - 0.1036 * x ** 4)
    def c(x):
        p = 0.4
        return comba / p ** 2 * (2 * p * x - x * x) if x < p else comba / (1 - p) ** 2 * (1 - 2 * p + 2 * p * x - x * x)
    for x in reversed(xs):           # upper, TE -> LE
        pts.append((x, c(x) + t(x)))
    for x in xs[1:-1]:               # lower, LE -> TE
        pts.append((x, c(x) - t(x)))
    return pts


def superficie(bm, secciones, mat_index=0):
    """secciones: list of (le_point Vector, chord, thickness, axis_chord Vector, axis_thick Vector, twist)."""
    anillos = []
    for le, cuerda, gros, ac, at in secciones:
        prof = perfil_ala(grosor=gros)
        anillos.append([le + ac * (x * cuerda) + at * (z * cuerda) for x, z in prof])
    vs = loft(bm, anillos, cerrar_ini=True, cerrar_fin=True, mat_fn=lambda i, j: mat_index)
    return vs


def lathe(bm, perfil, n=48, eje_origen=Vector(), mat_fn=None, cerrar_fin=False, cerrar_ini=False):
    """perfil: list of (x, r) around +X axis."""
    anillos = []
    for x, r in perfil:
        anillos.append([eje_origen + Vector((x, r * math.cos(2 * math.pi * j / n), r * math.sin(2 * math.pi * j / n))) for j in range(n)])
    return loft(bm, anillos, cerrar_ini=cerrar_ini, cerrar_fin=cerrar_fin, mat_fn=mat_fn)


def cielo(elev=38, rot=200, fuerza=1.0, sol=True):
    w = bpy.data.worlds.new('cielo')
    bpy.context.scene.world = w
    w.use_nodes = True
    nt = w.node_tree
    bg = nt.nodes['Background']
    s = nt.nodes.new('ShaderNodeTexSky')
    s.sky_type = 'MULTIPLE_SCATTERING'
    s.sun_elevation = math.radians(elev)
    s.sun_rotation = math.radians(rot)
    s.sun_disc = sol
    nt.links.new(s.outputs['Color'], bg.inputs['Color'])
    bg.inputs['Strength'].default_value = fuerza
    return w


def render(ruta, ancho, alto, muestras=128):
    sc = bpy.context.scene
    sc.render.engine = 'CYCLES'
    sc.cycles.samples = muestras
    sc.cycles.use_denoising = True
    try:
        sc.cycles.denoiser = 'OPENIMAGEDENOISE'
    except Exception as e:
        print('denoiser', e)
    sc.cycles.device = 'CPU'
    sc.render.film_transparent = True
    sc.render.resolution_x, sc.render.resolution_y = ancho, alto
    sc.render.resolution_percentage = 100
    sc.render.image_settings.file_format = 'PNG'
    sc.render.image_settings.color_mode = 'RGBA'
    sc.render.filepath = ruta
    try:
        sc.view_settings.view_transform = 'AgX'
        sc.view_settings.look = 'AgX - Medium High Contrast'
    except Exception as e:
        print('look', e)
    sc.render.threads_mode = 'AUTO'
    bpy.ops.render.render(write_still=True)


def camara(pos, mira, lente=50, roll=0.0):
    cam = bpy.data.cameras.new('cam')
    cam.lens = lente
    ob = bpy.data.objects.new('cam', cam)
    bpy.context.collection.objects.link(ob)
    ob.location = pos
    d = (Vector(mira) - Vector(pos)).normalized()
    ob.rotation_euler = d.to_track_quat('-Z', 'Y').to_euler()
    ob.rotation_euler.rotate_axis('Z', math.radians(roll))
    bpy.context.scene.camera = ob
    return ob
