# Red spiny lobster (Panulirus interruptus), modelled from scratch. Head at +X, left +Y, up +Z.
import sys, os, math, random, bpy, bmesh
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import *

limpiar()
random.seed(4)


def concha(nombre, oscuro, claro, manchas=True):
    """Wet lobster shell: two reds mixed by noise, pale speckles, glossy coat."""
    m = bpy.data.materials.new(nombre); m.use_nodes = True
    nt = m.node_tree; p = nt.nodes['Principled BSDF']
    tc = nt.nodes.new('ShaderNodeTexCoord')
    n1 = nt.nodes.new('ShaderNodeTexNoise'); n1.inputs['Scale'].default_value = 0.35; n1.inputs['Detail'].default_value = 6
    nt.links.new(tc.outputs['Object'], n1.inputs['Vector'])
    mix = nt.nodes.new('ShaderNodeMix'); mix.data_type = 'RGBA'
    mix.inputs['A'].default_value = (*hexlin(oscuro), 1); mix.inputs['B'].default_value = (*hexlin(claro), 1)
    nt.links.new(n1.outputs['Fac'], mix.inputs['Factor'])
    col = mix.outputs['Result']
    if manchas:
        v = nt.nodes.new('ShaderNodeTexVoronoi'); v.inputs['Scale'].default_value = 2.2
        nt.links.new(tc.outputs['Object'], v.inputs['Vector'])
        r = nt.nodes.new('ShaderNodeValToRGB')
        r.color_ramp.elements[0].position = 0.0; r.color_ramp.elements[0].color = (1, 1, 1, 1)
        r.color_ramp.elements[1].position = 0.055; r.color_ramp.elements[1].color = (0, 0, 0, 1)
        nt.links.new(v.outputs['Distance'], r.inputs['Fac'])
        mix2 = nt.nodes.new('ShaderNodeMix'); mix2.data_type = 'RGBA'
        mix2.inputs['B'].default_value = (*hexlin('#C8693A'), 1)
        nt.links.new(r.outputs['Color'], mix2.inputs['Factor']); nt.links.new(col, mix2.inputs['A'])
        col = mix2.outputs['Result']
    nt.links.new(col, p.inputs['Base Color'])
    p.inputs['Roughness'].default_value = 0.38
    p.inputs['Coat Weight'].default_value = 0.55
    p.inputs['Coat Roughness'].default_value = 0.1
    p.inputs['Subsurface Weight'].default_value = 0.03
    p.inputs['Subsurface Radius'].default_value = (0.6, 0.15, 0.08)
    # shell texture bump
    n2 = nt.nodes.new('ShaderNodeTexNoise'); n2.inputs['Scale'].default_value = 6; n2.inputs['Detail'].default_value = 8
    nt.links.new(tc.outputs['Object'], n2.inputs['Vector'])
    b = nt.nodes.new('ShaderNodeBump'); b.inputs['Strength'].default_value = 0.25
    nt.links.new(n2.outputs['Fac'], b.inputs['Height']); nt.links.new(b.outputs['Normal'], p.inputs['Normal'])
    return m


roja = concha('concha', '#470A06', '#8E2414')
pata = concha('pata', '#560E08', '#952815', manchas=False)
antena = concha('antena', '#3C0805', '#7A1D0F', manchas=False)
ojo = mat('ojo', (0.005, 0.005, 0.006), rough=0.05, coat=1.0)
espina = concha('espina', '#9A2C16', '#D9703F', manchas=False)


def seccion(cx, cz, w, h, n=40, ex=2.4, plano=0.35):
    pts = []
    for j in range(n):
        t = 2 * math.pi * j / n
        c, s = math.cos(t), math.sin(t)
        y = w * math.copysign(abs(c) ** (2 / ex), c)
        z = h * math.copysign(abs(s) ** (2 / ex), s)
        if z < 0:
            z *= plano + (1 - plano) * 0.6     # flatter underside
        pts.append(Vector((cx, y, cz + z)))
    return pts


def tubo(nombre, pts, radios, m, n=14, cerrar=True):
    bm = bmesh.new()
    anillos = []
    for i, (p, r) in enumerate(zip(pts, radios)):
        a = pts[max(0, i - 1)]; b = pts[min(len(pts) - 1, i + 1)]
        d = (b - a).normalized()
        u = d.cross(Vector((0, 0, 1)))
        if u.length < 1e-3:
            u = d.cross(Vector((0, 1, 0)))
        u.normalize(); v = d.cross(u)
        anillos.append([p + (u * math.cos(2 * math.pi * j / n) + v * math.sin(2 * math.pi * j / n)) * r for j in range(n)])
    loft(bm, anillos, cerrar_ini=cerrar, cerrar_fin=cerrar)
    return objeto(nombre, bm, [m])


def cono(nombre, base, punta, r, m, seg=10):
    base, punta = Vector(base), Vector(punta)
    bm = bmesh.new()
    bmesh.ops.create_cone(bm, cap_ends=True, segments=seg, radius1=r, radius2=0.0, depth=(punta - base).length)
    o = objeto(nombre, bm, [m])
    o.location = (base + punta) / 2
    o.rotation_euler = (punta - base).to_track_quat('Z', 'Y').to_euler()
    return o


def bezier(p0, p1, p2, p3, n):
    out = []
    for i in range(n + 1):
        t = i / n
        a = (1 - t) ** 3; b = 3 * (1 - t) ** 2 * t; c = 3 * (1 - t) * t * t; d = t ** 3
        out.append(p0 * a + p1 * b + p2 * c + p3 * d)
    return out


# --- carapace (cephalothorax) ---
Z0 = 2.4
def perfil_cefalo(x):
    if x > 8.2:
        f = math.sqrt(max(0.02, 1 - ((x - 8.2) / 2.4) ** 2))
    elif x < 0.6:
        f = 0.9 + 0.1 * x / 0.6
    else:
        f = 1.0
    return f

xs = [-0.4 + i * 0.25 for i in range(45)]
anillos = []
for x in xs:
    f = perfil_cefalo(x)
    w = 2.6 * f * (0.92 + 0.08 * math.sin(min(1, max(0, (x + 0.4) / 9)) * math.pi))
    h = 2.25 * f
    anillos.append(seccion(x, Z0 + 0.15 * f, w, h))
bm = bmesh.new(); loft(bm, anillos, cerrar_ini=True, cerrar_fin=True)
cefalo = objeto('cefalo', bm, [roja]); cefalo.modifiers.new('s', 'SUBSURF').levels = 1
cefalo.modifiers['s'].render_levels = 1

# cervical groove hint: a slightly darker ring as a thin torus-like tube on top
gpts = [Vector((5.0 - 0.9 * math.cos(a) ** 2, 2.62 * math.sin(a), Z0 + 0.15 + 2.27 * abs(math.cos(a)) ** 0.85)) for a in [(-80 + i * 5) * math.pi / 180 for i in range(33)]]
tubo('surco', gpts, [0.07] * len(gpts), antena, n=8)

# spines over the carapace, pointing forward
for k in range(150):
    x = random.uniform(1.0, 9.4)
    a = random.uniform(-1.25, 1.25)
    f = perfil_cefalo(x)
    w, h = 2.6 * f, 2.25 * f
    c, s = math.sin(a), math.cos(a)
    y = w * math.copysign(abs(c) ** (2 / 2.4), c); z = Z0 + 0.15 * f + h * abs(s) ** (2 / 2.4)
    nrm = Vector((0.0, y / w, (z - Z0) / h)).normalized()
    base = Vector((x, y, z)) - nrm * 0.05
    L = random.uniform(0.3, 0.75) * (1.4 if x > 7 else 1)
    tip = base + (nrm * 0.55 + Vector((0.8, 0, 0))).normalized() * L
    cono('espina', base, tip, random.uniform(0.1, 0.18), espina, seg=8)
# supraorbital horns
for lado in (1, -1):
    cono('cuerno', (9.4, lado * 0.95, Z0 + 1.7), (11.3, lado * 1.25, Z0 + 2.6), 0.42, espina, seg=14)
    bpy.ops.mesh.primitive_uv_sphere_add(radius=0.36, location=(10.25, lado * 1.05, Z0 + 1.05))
    o = bpy.context.active_object; o.data.materials.append(ojo); bpy.ops.object.shade_smooth()

# --- abdomen: 6 overlapping segments, slightly arching down ---
for k in range(6):
    x0 = -0.2 - k * 1.95
    w0 = 2.45 - 0.17 * k; h0 = 1.85 - 0.13 * k; z0 = Z0 - 0.25 - 0.16 * k
    anillos = []
    for i in range(7):
        u = i / 6
        bul = 1 + 0.07 * math.sin(u * math.pi)
        anillos.append(seccion(x0 - u * 2.25, z0 - u * 0.12, w0 * bul * (1 - 0.06 * u), h0 * bul * (1 - 0.05 * u), ex=2.2))
    bm = bmesh.new(); loft(bm, anillos, cerrar_ini=True, cerrar_fin=True)
    o = objeto('segmento', bm, [roja]); md = o.modifiers.new('s', 'SUBSURF'); md.levels = md.render_levels = 1
    for j in range(5):     # rough transverse ridge at the front of each segment
        yy = (j - 2) * w0 * 0.32
        cono('grano', (x0 - 0.35, yy, z0 + h0 * (0.98 - 0.08 * abs(j - 2))), (x0 - 0.65, yy, z0 + h0 * (1.08 - 0.08 * abs(j - 2))), 0.1, espina, seg=6)
    for lado in (1, -1):   # pleura pointing down-back
        cono('pleura', (x0 - 1.0, lado * (w0 - 0.15), z0 - 0.4), (x0 - 1.9, lado * (w0 + 0.05), z0 - 1.5), 0.45, roja, seg=10)

# --- tail fan ---
xt = -0.2 - 6 * 1.95 - 0.1
zt = Z0 - 0.25 - 0.16 * 6 - 0.2
def paleta(nombre, raiz, ang, largo, ancho):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=32, ring_count=16, radius=1)
    o = bpy.context.active_object
    o.scale = (largo / 2, ancho / 2, 0.24)
    o.location = (raiz[0] - math.cos(ang) * largo / 2, raiz[1] + math.sin(ang) * largo / 2, raiz[2])
    o.rotation_euler = (0, math.radians(-4), -ang)
    o.data.materials.append(pata); bpy.ops.object.shade_smooth()
    return o
paleta('telson', (xt, 0, zt), 0.0, 4.2, 2.3)
for lado in (1, -1):
    paleta('uropodo', (xt + 0.2, lado * 0.6, zt + 0.05), lado * math.radians(22), 4.0, 1.9)
    paleta('uropodo', (xt + 0.3, lado * 1.0, zt + 0.1), lado * math.radians(46), 3.8, 1.8)

# --- antennae: thick spiny base, long whips sweeping out and back ---
BASES = {}
for lado in (1, -1):
    base = Vector((10.4, lado * 1.35, Z0 + 0.4))
    p1 = base + Vector((2.2, lado * 1.1, 0.5)); p2 = p1 + Vector((2.0, lado * 1.0, 0.35))
    ped = bezier(base, base + Vector((1.2, lado * 0.6, 0.3)), p2 - Vector((1.0, lado * 0.5, 0.2)), p2, 12)
    lad = 'a' if lado > 0 else 'b'
    tubo('antena_' + lad, ped, [0.62 - 0.22 * i / 12 for i in range(13)], antena)
    for i in range(2, 12, 2):
        q = ped[i]
        cono('antena_' + lad, q, q + Vector((0.35, lado * 0.25, 0.45)), 0.12, espina, seg=8)
    BASES[lad] = base.copy()
    # flagellum
    f0 = p2
    fl = bezier(f0, f0 + Vector((6, lado * 2.5, 1.4)), f0 + Vector((8, lado * 9, 0.6)), f0 + Vector((3, lado * 15, -1.0)), 60)
    tubo('antena_' + lad, fl, [0.38 * (1 - i / 60) ** 1.2 + 0.03 for i in range(61)], antena, n=10)
    # antennules: thin, forked
    a0 = Vector((10.6, lado * 0.45, Z0 + 0.2))
    a1 = a0 + Vector((3.2, lado * 0.4, 0.6))
    tubo('antenula', bezier(a0, a0 + Vector((1.2, 0, 0.2)), a1 - Vector((1, 0, 0.1)), a1, 10), [0.16 - 0.06 * i / 10 for i in range(11)], pata, n=8)
    for dz in (0.5, -0.1):
        e = a1 + Vector((2.6, lado * (0.4 + dz), dz + 0.4))
        tubo('flagelo', bezier(a1, a1 + Vector((0.8, 0, 0.1)), e - Vector((0.8, 0, 0)), e, 10), [0.08 - 0.06 * i / 10 for i in range(11)], pata, n=6)

# --- walking legs: 5 pairs, jointed, standing ---
for k, x in enumerate((8.0, 6.6, 5.1, 3.6, 2.1)):
    ad = (2 - k) * 0.9                      # front legs reach forward, back legs back
    for lado in (1, -1):
        p0 = Vector((x, lado * 2.0, Z0 - 0.9))
        p1 = Vector((x + ad * 0.4, lado * 4.3, Z0 + 0.9))
        p2 = Vector((x + ad * 0.9, lado * 5.9, Z0 - 0.6))
        p3 = Vector((x + ad * 1.3, lado * 6.6, -0.05))
        largo = 1.0 if k > 0 else 1.15
        tubo('pata', [p0, p1], [0.36, 0.3], pata, n=10)
        tubo('pata', [p1, p2], [0.3, 0.22], pata, n=10)
        tubo('pata', [p2, p3], [0.2, 0.06], pata, n=10)
        for q in (p1, p2):
            bpy.ops.mesh.primitive_uv_sphere_add(radius=0.3 if q is p1 else 0.23, location=q)
            o = bpy.context.active_object; o.data.materials.append(pata); bpy.ops.object.shade_smooth()

# --- light & camera (same sky/sun as the boat and plane) ---
cielo(elev=34, rot=120, fuerza=0.3, sol=False)
sol = bpy.data.lights.new('sol', 'SUN'); sol.energy = 4.4; sol.angle = math.radians(2.0); sol.color = (1.0, 0.96, 0.9)
so = bpy.data.objects.new('sol', sol); bpy.context.collection.objects.link(so)
so.rotation_euler = (math.radians(42), math.radians(0), math.radians(150))
relleno = bpy.data.lights.new('relleno', 'AREA'); relleno.energy = 900; relleno.size = 20; relleno.color = (0.75, 0.85, 1.0)
ro = bpy.data.objects.new('relleno', relleno); bpy.context.collection.objects.link(ro)
ro.location = (-10, -25, 18); ro.rotation_euler = (Vector((0, 0, 2)) - ro.location).to_track_quat('-Z', 'Y').to_euler()

camara((22, 33, 48), (1.0, 2.5, 0.5), lente=36)
args = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
salida = args[0] if args else '/home/claude/shots/langosta3d.png'
q = int(args[1]) if len(args) > 1 else 16
capa = args[2] if len(args) > 2 else 'todo'     # todo | cuerpo | antena_a | antena_b
# Layers for animation: render one part alone from the same camera, so they stack exactly.
for o in bpy.data.objects:
    if o.type != 'MESH':
        continue
    es_antena = o.name.startswith('antena_')
    if capa == 'cuerpo':
        o.hide_render = es_antena
    elif capa.startswith('antena_'):
        o.hide_render = not o.name.startswith(capa)
# antenna base pivots in image coordinates (0..1 from top-left)
from bpy_extras.object_utils import world_to_camera_view
sc = bpy.context.scene
bpy.context.view_layer.update()
for k, b in BASES.items():
    v = world_to_camera_view(sc, sc.camera, b)
    print('PIVOTE', k, round(v.x, 5), round(1 - v.y, 5))
w, h = (1800, 1500) if q > 32 else (720, 600)
render(salida, w, h, muestras=q)
