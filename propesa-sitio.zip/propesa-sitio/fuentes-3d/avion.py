# Generic twin-engine wide-body freighter, modelled from scratch. Nose at +X, left wing +Y, up +Z.
import sys, math, bpy, bmesh
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from comun import *

limpiar()
L, R = 64.0, 3.1
blanco = mat('pintura', (0.86, 0.87, 0.89), rough=0.3, coat=0.4)
marino = mat('marino', hexlin('#0A2373'), rough=0.3, coat=0.4)
azul = mat('azul', hexlin('#0583C3'), rough=0.3, coat=0.4)
cristal = mat('cristal', (0.01, 0.012, 0.018), rough=0.05, coat=1.0)
gris = mat('gris', (0.55, 0.57, 0.6), rough=0.38, metal=0.55)
metal = mat('metal', (0.8, 0.8, 0.82), rough=0.18, metal=1.0)
oscuro = mat('oscuro', (0.03, 0.03, 0.035), rough=0.35, metal=0.6)
metal_borde = mat('borde', (0.72, 0.73, 0.75), rough=0.2, metal=1.0)
panza = mat('panza', (0.62, 0.64, 0.67), rough=0.35, coat=0.2)


def seccion(x):
    """top, bottom, half-width of the fuselage at station x (0 = nose tip)."""
    if x < 10:
        s = x / 10
        e = math.sqrt(max(0.0, 1 - (1 - s) ** 2))
        top = -0.5 + (R + 0.5) * e ** 0.75
        bot = -0.5 - (R - 0.5) * e ** 1.05
        w = R * e ** 0.9
    elif x <= 42:
        top, bot, w = R, -R, R
    else:
        s = (x - 42) / (L - 42)
        top = R - 1.1 * s ** 1.6
        bot = -R + (R + 1.35) * s ** 1.25
        w = R * (1 - s) ** 0.85 + 0.28 * s
    return top, bot, w


xs = [0.02, 0.12, 0.3, 0.55, 0.85] + [1.1 + i * 0.1 for i in range(89)] + [10.5 + i * 1.0 for i in range(32)] + [42.5 + i * 0.75 for i in range(29)] + [L - 0.15]
N = 144


def mat_fuselaje(x, ang):
    # ang: degrees above horizontal on the side (0 = side, 90 = top), symmetric in y
    if 11 < x < 50 and -8 < ang < -5:
        return 1                             # navy cheatline
    if 11 < x < 48 and -11.5 < ang < -9.5:
        return 2                             # blue line
    if ang < -55:
        return 4                             # lighter belly
    return 0


def lineas_panel(m, escala):
    nt = m.node_tree
    p = nt.nodes['Principled BSDF']
    tc = nt.nodes.new('ShaderNodeTexCoord')
    wv = nt.nodes.new('ShaderNodeTexWave'); wv.wave_type = 'BANDS'; wv.bands_direction = 'X'
    wv.inputs['Scale'].default_value = escala; wv.inputs['Distortion'].default_value = 0
    wv.inputs['Detail'].default_value = 0
    ramp = nt.nodes.new('ShaderNodeValToRGB')
    ramp.color_ramp.elements[0].position = 0.0; ramp.color_ramp.elements[0].color = (0, 0, 0, 1)
    ramp.color_ramp.elements[1].position = 0.04; ramp.color_ramp.elements[1].color = (1, 1, 1, 1)
    bump = nt.nodes.new('ShaderNodeBump'); bump.inputs['Strength'].default_value = 0.12; bump.inputs['Distance'].default_value = 0.02
    nt.links.new(tc.outputs['Object'], wv.inputs['Vector'])
    nt.links.new(wv.outputs['Fac'], ramp.inputs['Fac'])
    nt.links.new(ramp.outputs['Color'], bump.inputs['Height'])
    nt.links.new(bump.outputs['Normal'], p.inputs['Normal'])


lineas_panel(blanco, 0.9)


def ventanas_cabina(m):
    # smooth cockpit-window mask from object coords: station x, angle above the side
    nt = m.node_tree
    p = nt.nodes['Principled BSDF']
    out = nt.nodes['Material Output']
    tc = nt.nodes.new('ShaderNodeTexCoord'); sp = nt.nodes.new('ShaderNodeSeparateXYZ')
    nt.links.new(tc.outputs['Object'], sp.inputs['Vector'])
    def op(o, a, b=None):
        n = nt.nodes.new('ShaderNodeMath'); n.operation = o
        for k, v in enumerate((a, b)):
            if v is None: continue
            if isinstance(v, (int, float)): n.inputs[k].default_value = v
            else: nt.links.new(v, n.inputs[k])
        return n.outputs[0]
    x = op('SUBTRACT', L / 2, sp.outputs['X'])
    ang = op('MULTIPLY', op('ARCTAN2', sp.outputs['Z'], op('ABSOLUTE', sp.outputs['Y'])), 57.2958)
    k = op('SUBTRACT', 6.4, x)
    lo = op('ADD', 23.0, op('MULTIPLY', k, 3.0)); hi = op('ADD', 33.0, op('MULTIPLY', k, 6.5))
    def suave(a, b):   # 1 where a > b, soft edge
        return op('MINIMUM', op('MAXIMUM', op('MULTIPLY', op('SUBTRACT', a, b), 2.5), 0.0), 1.0)
    mk = op('MULTIPLY', suave(ang, lo), suave(hi, ang))
    mk = op('MULTIPLY', mk, op('MULTIPLY', suave(op('MULTIPLY', x, 10.0), 31.0), suave(64.0, op('MULTIPLY', x, 10.0))))
    marco = op('MAXIMUM', op('MULTIPLY', suave(op('MULTIPLY', x, 10.0), 46.0), suave(47.6, op('MULTIPLY', x, 10.0))),
                          op('MULTIPLY', suave(op('MULTIPLY', x, 10.0), 55.4), suave(56.8, op('MULTIPLY', x, 10.0))))
    mk = op('MULTIPLY', mk, op('SUBTRACT', 1.0, marco))
    g = nt.nodes.new('ShaderNodeBsdfPrincipled')
    g.inputs['Base Color'].default_value = (0.01, 0.012, 0.018, 1); g.inputs['Roughness'].default_value = 0.04
    g.inputs['Coat Weight'].default_value = 1.0
    mx = nt.nodes.new('ShaderNodeMixShader'); nt.links.new(mk, mx.inputs['Fac'])
    nt.links.new(p.outputs['BSDF'], mx.inputs[1]); nt.links.new(g.outputs['BSDF'], mx.inputs[2])
    nt.links.new(mx.outputs['Shader'], out.inputs['Surface'])


ventanas_cabina(blanco)
bm = bmesh.new()
anillos, info = [], []
for x in xs:
    top, bot, w = seccion(x)
    c, h = (top + bot) / 2, (top - bot) / 2
    anillo = []
    for j in range(N):
        t = 2 * math.pi * (j + 0.5) / N
        anillo.append(Vector((L / 2 - x, w * math.cos(t), c + h * math.sin(t))))
    anillos.append(anillo)
    info.append(x)


def mf(i, j):
    x = (info[i] + info[i + 1]) / 2
    t = 2 * math.pi * (j + 1) / N
    ang = math.degrees(math.asin(math.sin(t)))
    return mat_fuselaje(x, ang)


loft(bm, anillos, cerrar_ini=True, cerrar_fin=True, mat_fn=mf)
fus = objeto('fuselaje', bm, [blanco, marino, azul, cristal, panza])

# --- wings (low, swept, dihedral) ---
def ala(lado, raiz_x, raiz_c, punta_c, semi, flecha, diedro, z0, gros_r, gros_p, nombre, m, y0=0.0, vertical=False):
    bm = bmesh.new()
    secs = []
    n = 14
    for i in range(n + 1):
        f = i / n
        span = y0 + (semi - y0) * f
        c = raiz_c + (punta_c - raiz_c) * f
        sweep = (span - y0) * math.tan(math.radians(flecha))
        qc = raiz_c * 0.25
        le_x = raiz_x - sweep - (qc - c * 0.25) * 0  # quarter-chord sweep approx
        le_x = raiz_x + (raiz_c - c) * 0.25 - sweep
        if vertical:
            le = Vector((L / 2 - 0 + 0, 0, 0))
            le = Vector((le_x, 0, z0 + span))
            ac, at = Vector((-1, 0, 0)), Vector((0, 1, 0))
        else:
            le = Vector((le_x, lado * span, z0 + (span - y0) * math.tan(math.radians(diedro))))
            ac, at = Vector((-1, 0, 0)), Vector((0, 0, 1))
        g = gros_r + (gros_p - gros_r) * f
        secs.append((le, c, g, ac, at))
    if lado < 0 and not vertical:
        secs = secs[::-1]
    vs = superficie(bm, secs)
    o = objeto(nombre, bm, [m, metal_borde])
    me = o.data
    n_prof = len(perfil_ala())
    for p in me.polygons:
        if p.loop_total == 4:
            js = [vi % n_prof for vi in p.vertices]
            if all(18 <= j <= 26 for j in js) and nombre in ('ala', 'estab'):
                p.material_index = 1
    return o


# x positions are in object space where nose is +L/2
for lado in (1, -1):
    ala(lado, L / 2 - 23, 12.5, 2.4, 32.5, 31, 6, -2.0, 0.13, 0.09, 'ala', gris, y0=1.0)
    ala(lado, L / 2 - 53.5, 6.2, 2.2, 10.5, 36, 7, 0.55, 0.1, 0.08, 'estab', blanco, y0=0.5)
ala(1, L / 2 - 49, 10.5, 3.8, 11.8, 42, 0, 1.6, 0.11, 0.09, 'deriva', marino, y0=0.0, vertical=True)

# --- engines ---
for lado in (1, -1):
    y = lado * 10.2
    le_x = L / 2 - 23 + 12.5 * 0.25 * 0 - (abs(y) - 1.0) * math.tan(math.radians(31)) + 0.0
    cx = le_x + 4.2          # intake lip ahead of the wing leading edge
    z = -2.0 + (abs(y) - 1.0) * math.tan(math.radians(6)) - 2.3
    bm = bmesh.new()
    perfil = [(0.0, 1.62), (-0.15, 1.82), (-0.6, 1.95), (-2.0, 2.02), (-4.5, 1.9), (-6.6, 1.45), (-7.4, 1.15)]
    def mn(i, j):
        return 1 if i < 2 else 0
    lathe(bm, [(cx + a, r) for a, r in perfil], n=56, eje_origen=Vector((0, y, z)), mat_fn=mn)
    o = objeto('nacela', bm, [blanco, metal])
    # inner duct + fan face + spinner
    bm = bmesh.new()
    lathe(bm, [(cx + 0.0, 1.62), (cx - 0.9, 1.55)], n=56, eje_origen=Vector((0, y, z)))
    lathe(bm, [(cx - 0.9, 1.55), (cx - 0.9, 0.001)], n=56, eje_origen=Vector((0, y, z)))
    objeto('ducto', bm, [oscuro])
    bm = bmesh.new()
    lathe(bm, [(cx - 0.2, 0.001), (cx - 0.45, 0.25), (cx - 0.75, 0.42), (cx - 0.9, 0.46)], n=40, eje_origen=Vector((0, y, z)))
    objeto('cono', bm, [metal])
    # exhaust cone
    bm = bmesh.new()
    lathe(bm, [(cx - 7.4, 0.9), (cx - 8.3, 0.6), (cx - 9.0, 0.05)], n=40, eje_origen=Vector((0, y, z)))
    objeto('escape', bm, [gris])
    # pylon
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1)
    for v in bm.verts:
        v.co.x *= 6.5; v.co.y *= 0.45; v.co.z *= 1.6
    o = objeto('pilon', bm, [blanco], suave=False)
    o.location = (cx - 4.8, y, z + 2.2)
    o.rotation_euler = (0, math.radians(-6), 0)
    bv = o.modifiers.new('bv', 'BEVEL'); bv.width = 0.18; bv.segments = 3

for lado in (1, -1):
    for sp in (6.5, 13.5, 19.0):
        c = 12.5 + (2.4 - 12.5) * (sp - 1) / 31.5
        le = L / 2 - 23 + (12.5 - c) * 0.25 - (sp - 1) * math.tan(math.radians(31))
        z = -2.0 + (sp - 1) * math.tan(math.radians(6))
        bm = bmesh.new()
        lathe(bm, [(0, 0.001), (-0.8, 0.25), (-2.5, 0.32), (-4.4, 0.18), (-5.2, 0.001)], n=20)
        o = objeto('carenado', bm, [gris])
        o.location = (le - c * 0.55, lado * sp, z - 0.25)
        o.scale = (1, 0.8, 1.15)

# group under an empty so we can pose the whole aircraft
raiz = bpy.data.objects.new('avion', None)
bpy.context.collection.objects.link(raiz)
for o in list(bpy.context.collection.objects):
    if o is not raiz and o.type == 'MESH':
        o.parent = raiz
raiz.rotation_euler = (math.radians(-14), math.radians(-9), math.radians(-6))   # bank, climb, yaw

cielo(elev=34, rot=120, fuerza=0.32, sol=False)
sol = bpy.data.lights.new('sol', 'SUN'); sol.energy = 4.2; sol.angle = math.radians(1.2)
sol.color = (1.0, 0.96, 0.9)
so = bpy.data.objects.new('sol', sol); bpy.context.collection.objects.link(so)
so.rotation_euler = (math.radians(38), math.radians(0), math.radians(160))

camara((60, 116, 48), (0, 3, -3), lente=55, roll=13)
salida = sys.argv[sys.argv.index('--') + 1] if '--' in sys.argv else '/home/claude/shots/avion.png'
q = int(sys.argv[sys.argv.index('--') + 2]) if '--' in sys.argv else 16
w, h = (2000, 1300) if q > 32 else (800, 520)
render(salida, w, h, muestras=q)
