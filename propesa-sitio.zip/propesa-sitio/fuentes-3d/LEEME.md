# Fuentes de las imágenes alrededor del globo

Modelos hechos desde cero en Blender (módulo `bpy`, motor Cycles). Para volver a generar:

```
pip install bpy pillow
python3 avion.py -- avion.png 128      # 2000×1300, unos 2 min
python3 barco.py -- barco.png 160      # 1800×1200, unos 4 min
for c in cuerpo antena_a antena_b; do python3 langosta.py -- capa-$c.png 128 $c; done   # 3 capas alineadas, imprime los pivotes
python3 -I png_web.py avion.png ../img/avion-carga.png 720 256
python3 -I png_web.py barco.png ../img/barco-langostero.png 600
python3 -I capas_web.py 640 ../img/langosta-roja <pivA_x> <pivA_y> <pivB_x> <pivB_y> capa-cuerpo.png:cuerpo capa-antena_a.png:antena-a capa-antena_b.png:antena-b   # pivotes → .antena-a/.antena-b en estilos.css
rsvg-convert -w 600 langosta-trazo.svg -o trazo.png && python3 -I png_web.py trazo.png ../img/langosta-trazo.png 280 64
```
