# Crop a transparent render to its subject, resize to a target width, and save a compact PNG.
# usage: python3 -I png_web.py in.png out.png width [colors]
import sys
from PIL import Image

src, dst, ancho = sys.argv[1], sys.argv[2], int(sys.argv[3])
colores = int(sys.argv[4]) if len(sys.argv) > 4 else 0
im = Image.open(src).convert('RGBA')
a = im.getchannel('A').point(lambda v: 255 if v > 6 else 0)
caja = a.getbbox()
pad = 8
caja = (max(0, caja[0] - pad), max(0, caja[1] - pad), min(im.width, caja[2] + pad), min(im.height, caja[3] + pad))
im = im.crop(caja)
im = im.resize((ancho, round(im.height * ancho / im.width)), Image.LANCZOS)
if colores:
    im = im.quantize(colors=colores, method=Image.Quantize.FASTOCTREE, dither=Image.Dither.FLOYDSTEINBERG)
im.save(dst, optimize=True)
print(dst, im.size, round(__import__('os').path.getsize(dst) / 1024), 'KB')
