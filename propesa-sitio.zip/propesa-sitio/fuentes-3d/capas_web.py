# Crop aligned render layers with one shared box, resize, quantize, and report pivots in % of the crop.
# usage: python3 -I capas_web.py ancho out_prefix pivA_x pivA_y pivB_x pivB_y layer1.png[:name] ...
import sys, os
from PIL import Image

ancho, pref = int(sys.argv[1]), sys.argv[2]
piv = {'a': (float(sys.argv[3]), float(sys.argv[4])), 'b': (float(sys.argv[5]), float(sys.argv[6]))}
capas = [a.split(':') for a in sys.argv[7:]]
ims = [(n, Image.open(p).convert('RGBA')) for p, n in capas]
W, H = ims[0][1].size
caja = None
for _, im in ims:
    b = im.getchannel('A').point(lambda v: 255 if v > 6 else 0).getbbox()
    caja = b if caja is None else (min(caja[0], b[0]), min(caja[1], b[1]), max(caja[2], b[2]), max(caja[3], b[3]))
pad = 10
caja = (max(0, caja[0] - pad), max(0, caja[1] - pad), min(W, caja[2] + pad), min(H, caja[3] + pad))
cw, ch = caja[2] - caja[0], caja[3] - caja[1]
alto = round(ch * ancho / cw)
for n, im in ims:
    out = im.crop(caja).resize((ancho, alto), Image.LANCZOS)
    out = out.quantize(colors=256, method=Image.Quantize.FASTOCTREE, dither=Image.Dither.FLOYDSTEINBERG)
    ruta = f'{pref}-{n}.png'
    out.save(ruta, optimize=True)
    print(ruta, out.size, round(os.path.getsize(ruta) / 1024), 'KB')
for k, (fx, fy) in piv.items():
    print(f'pivote {k}: {100 * (fx * W - caja[0]) / cw:.1f}% {100 * (fy * H - caja[1]) / ch:.1f}%')
