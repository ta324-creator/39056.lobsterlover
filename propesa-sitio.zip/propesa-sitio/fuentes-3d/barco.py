# Commercial lobster boat, modelled from scratch: bow at +X, port +Y, up +Z, waterline z = 0.
import sys, math, bpy, bmesh
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from comun import *

limpiar()
LB, B = 14.0, 2.35
blanco = mat('blanco', (0.84, 0.85, 0.86), rough=0.28, coat=0.5)
casco_m = mat('casco', (0.84, 0.85, 0.86), rough=0.28, coat=0.5)
_nt = casco_m.node_tree; _p = _nt.nodes['Principled BSDF']
_tc = _nt.nodes.new('ShaderNodeTexCoord'); _sx = _nt.nodes.new('ShaderNodeSeparateXYZ')
_r = _nt.nodes.new('ShaderNodeValToRGB'); _r.color_ramp.interpolation = 'CONSTANT'
_e = _r.color_ramp.elements
_e[0].position = 0.0; _e[0].color = (*hexlin('#8E1E16'), 1)
_e[1].position = (0.14 + 2) / 6; _e[1].color = (*hexlin('#0A2373'), 1)
_e.new((0.36 + 2) / 6).color = (0.84, 0.85, 0.86, 1)
_e.new((1.62 + 2) / 6).color = (*hexlin('#0A2373'), 1)
_e.new((1.78 + 2) / 6).color = (0.84, 0.85, 0.86, 1)
_mr = _nt.nodes.new('ShaderNodeMapRange'); _mr.inputs['From Min'].default_value = -2; _mr.inputs['From Max'].default_value = 4
_nt.links.new(_tc.outputs['Object'], _sx.inputs['Vector']); _nt.links.new(_sx.outputs['Z'], _mr.inputs['Value'])
_nt.links.new(_mr.outputs['Result'], _r.inputs['Fac']); _nt.links.new(_r.outputs['Color'], _p.inputs['Base Color'])
fondo = mat('antiincrustante', hexlin('#8E1E16'), rough=0.6)
marino = mat('marino', hexlin('#0A2373'), rough=0.3, coat=0.4)
cubierta = mat('cubierta', (0.42, 0.44, 0.45), rough=0.8)
borda = mat('borda', (0.5, 0.33, 0.18), rough=0.45, coat=0.3)
cristal = mat('cristal', (0.01, 0.013, 0.02), rough=0.04, coat=1.0)
metal = mat('metal', (0.78, 0.78, 0.8), rough=0.22, metal=1.0)
negro = mat('negro', (0.02, 0.02, 0.022), rough=0.5)
amarillo = mat('trampa', (0.65, 0.48, 0.03), rough=0.45)
verde = mat('trampa2', (0.06, 0.2, 0.08), rough=0.45)
rojo = mat('boya', hexlin('#F0604B'), rough=0.35, coat=0.3)
azul = mat('azul', hexlin('#0583C3'), rough=0.35, coat=0.3)


def estacion(s):
    """s 0 = transom, 1 = stem. returns half-beam, sheer z, keel z, deadrise exponent."""
    zs = 1.55 + 1.05 * s ** 2.4
    proa = max(0.0, (s - 0.5) / 0.5)
    b = B * (1 - proa ** 1.9) * (0.9 + 0.1 * min(1, s / 0.25))
    b = max(b, 0.04)
    zk = -0.85 + 1.5 * proa ** 2.6 + 0.25 * max(0, (0.12 - s)) / 0.12
    ex = 1.0 + 1.4 * proa
    return b, zs, zk, ex


K = 26
def anillo(s):
    b, zs, zk, ex = estacion(s)
    x = -LB / 2 + LB * s
    lado = []
    for i in range(K + 1):
        u = i / K
        y = b * (1 - (1 - u) ** (1.6 + ex))          # round-ish bilge, sharper forward
        z = zk + (zs - zk) * u ** 1.15
        lado.append((y, z))
    pts = [Vector((x, -y, z)) for y, z in reversed(lado)] + [Vector((x, y, z)) for y, z in lado[1:]]
    zd = zs - 0.55
    pts += [Vector((x, b - 0.1, zs)), Vector((x, b - 0.12, zd)), Vector((x, -b + 0.12, zd)), Vector((x, -b + 0.1, zs))]
    return pts


ss = [0.0, 0.01] + [0.02 + i * 0.012 for i in range(82)]
ss = [min(s, 0.995) for s in ss]
anillos = [anillo(s) for s in ss]
n = len(anillos[0])
nh = 2 * K + 1


def mf(i, j):
    if j >= nh:
        k = j - nh
        return 4 if k == 1 else 3          # cap rail / deck & bulwark
    return 0


bm = bmesh.new()
loft(bm, anillos, cerrar_ini=True, cerrar_fin=True, mat_fn=mf)
casco = objeto('casco', bm, [casco_m, fondo, marino, cubierta, borda])
sd = casco.modifiers.new('sub', 'SUBSURF'); sd.levels = sd.render_levels = 1


def caja(nombre, centro, medidas, m, bisel=0.05, rot=(0, 0, 0)):
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1)
    for v in bm.verts:
        v.co.x *= medidas[0]; v.co.y *= medidas[1]; v.co.z *= medidas[2]
    o = objeto(nombre, bm, [m], suave=False)
    o.location = centro
    o.rotation_euler = rot
    if bisel:
        bv = o.modifiers.new('bv', 'BEVEL'); bv.width = bisel; bv.segments = 3
    return o


def cilindro(nombre, a, b, r, m, seg=24):
    a, b = Vector(a), Vector(b)
    bm = bmesh.new()
    bmesh.ops.create_cone(bm, cap_ends=True, segments=seg, radius1=r, radius2=r, depth=(b - a).length)
    o = objeto(nombre, bm, [m])
    o.location = (a + b) / 2
    o.rotation_euler = (b - a).to_track_quat('Z', 'Y').to_euler()
    return o


# --- wheelhouse (forward of midships) ---
def zdeck(x):
    s = (x + LB / 2) / LB
    return estacion(s)[1] - 0.55

x0, x1 = -0.2, 3.6
zd = zdeck((x0 + x1) / 2)
bm = bmesh.new()
# trapezoid side profile: windshield slants back at the top
perfil = [(x0, zd), (x1, zd), (x1 - 0.25, zd + 1.25), (x1 - 0.75, zd + 2.15), (x0, zd + 2.15)]
anch = 1.65
vs_p = [bm.verts.new((x, anch, z)) for x, z in perfil]
vs_s = [bm.verts.new((x, -anch, z)) for x, z in perfil]
bm.faces.new(vs_p[::-1]); bm.faces.new(vs_s)
for i in range(len(perfil)):
    j = (i + 1) % len(perfil)
    bm.faces.new((vs_p[i], vs_p[j], vs_s[j], vs_s[i]))
bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
casa = objeto('caseta', bm, [blanco], suave=False)
bv = casa.modifiers.new('bv', 'BEVEL'); bv.width = 0.08; bv.segments = 3
# roof with overhang
caja('techo', ((x0 + x1 - 0.75) / 2 + 0.05, 0, zd + 2.22), (x1 - x0 + 0.1, 3.6, 0.14), blanco, bisel=0.05)
# windshield panes (front slope) and side windows
for k, yc in enumerate((-1.08, 0, 1.08)):
    a = Vector((x1 - 0.31, yc, zd + 1.38)); b = Vector((x1 - 0.71, yc, zd + 2.0))
    mid = (a + b) / 2
    ang = math.atan2(b.z - a.z, b.x - a.x)
    caja('parabrisas', mid + Vector((0.035, 0, 0)), ((b - a).length, 0.98, 0.04), cristal, bisel=0.02, rot=(0, -ang, 0))
for lado in (1, -1):
    for xc in (0.55, 1.75, 2.75):
        w = 1.0 if xc < 2.7 else 0.7
        caja('ventana', (xc, lado * (anch + 0.005), zd + 1.6), (w, 0.04, 0.6), cristal, bisel=0.02)
# mast, radar, antennas
cilindro('mastil', (0.3, 0, zd + 2.28), (0.3, 0, zd + 3.4), 0.06, metal)
caja('radar', (0.3, 0, zd + 3.42), (1.6, 0.16, 0.12), blanco, bisel=0.04)
cilindro('domo', (1.4, 0.7, zd + 2.28), (1.4, 0.7, zd + 2.62), 0.32, blanco, seg=32)
cilindro('antena1', (0.0, 1.5, zd + 2.28), (0.2, 1.6, zd + 5.2), 0.025, blanco)
cilindro('antena2', (0.0, -1.5, zd + 2.28), (0.15, -1.6, zd + 4.6), 0.025, blanco)
cilindro('chimenea', (-0.05, -1.2, zd + 0.2), (-0.05, -1.2, zd + 3.3), 0.11, negro)
# pot hauler davit on starboard, aft of the wheelhouse
cilindro('pescante', (-0.6, -1.95, zdeck(-0.6)), (-0.6, -1.95, zdeck(-0.6) + 1.7), 0.07, metal)
cilindro('brazo', (-0.6, -1.95, zdeck(-0.6) + 1.7), (-0.6, -2.55, zdeck(-0.6) + 2.0), 0.05, metal)
cilindro('polea', (-0.6, -2.5, zdeck(-0.6) + 1.88), (-0.6, -2.62, zdeck(-0.6) + 1.88), 0.16, negro)
cilindro('cabo', (-0.6, -2.56, zdeck(-0.6) + 1.72), (-0.6, -2.56, 0.0), 0.012, amarillo, seg=8)


# --- lobster traps: vinyl-coated wire mesh boxes ---
def trampa(nombre, centro, m, rot=0.0):
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1)
    bmesh.ops.subdivide_edges(bm, edges=bm.edges[:], cuts=7, use_grid_fill=True)
    for v in bm.verts:
        v.co.x *= 1.2; v.co.y *= 0.6; v.co.z *= 0.42
    o = objeto(nombre, bm, [m], suave=False)
    wf = o.modifiers.new('wf', 'WIREFRAME'); wf.thickness = 0.018; wf.use_even_offset = True
    o.location = centro
    o.rotation_euler = (0, 0, rot)
    # solid runners on the bottom
    return o

zt = zdeck(-4.0)
k = 0
for fila, yc in enumerate((-1.25, -0.6, 0.05, 0.7, 1.35)):
    if fila == 4:
        continue
    for capa in range(3 if fila in (1, 2) else 2):
        for col, xc in enumerate((-5.0, -3.7, -2.4)):
            if capa == 2 and col == 0:
                continue
            m = amarillo if (fila + capa + col) % 3 else verde
            trampa('trampa', (xc + 0.04 * ((k * 7) % 3 - 1), yc, zt + 0.22 + capa * 0.43), m, rot=math.radians(((k * 13) % 5 - 2) * 1.2))
            k += 1


# --- buoys on the starboard rail and on the trap stack ---
def boya(centro, c1, c2, rot=(0, 0, 0)):
    bm = bmesh.new()
    lathe(bm, [(0.34, 0.001), (0.3, 0.1), (0.18, 0.15), (0.0, 0.16), (-0.18, 0.15), (-0.3, 0.1), (-0.34, 0.001)], n=32,
          mat_fn=lambda i, j: 0 if i < 3 else 1)
    o = objeto('boya', bm, [c1, c2])
    o.location = centro; o.rotation_euler = rot
    cilindro('vara', Vector(centro) + Vector((0, 0, -0.5)), Vector(centro) + Vector((0, 0, 0.7)), 0.018, blanco)
    o.rotation_euler = (0, math.radians(90), 0)
    return o

for i, xc in enumerate((-6.0, -5.2, -4.4)):
    boya((xc, -2.0, zdeck(xc) + 0.95), rojo if i % 2 == 0 else azul, blanco)

# water: dark ocean disc that fades to transparent, with a little foam round the hull
agua = bpy.data.materials.new('agua'); agua.use_nodes = True
nt = agua.node_tree; nt.nodes.clear()
out = nt.nodes.new('ShaderNodeOutputMaterial')
p = nt.nodes.new('ShaderNodeBsdfPrincipled')
p.inputs['Base Color'].default_value = (*hexlin('#082457'), 1)
p.inputs['Roughness'].default_value = 0.16
p.inputs['Specular IOR Level'].default_value = 0.25
tc = nt.nodes.new('ShaderNodeTexCoord')
noi = nt.nodes.new('ShaderNodeTexNoise'); noi.inputs['Scale'].default_value = 0.9; noi.inputs['Detail'].default_value = 8
bump = nt.nodes.new('ShaderNodeBump'); bump.inputs['Strength'].default_value = 0.35
nt.links.new(tc.outputs['Object'], noi.inputs['Vector']); nt.links.new(noi.outputs['Fac'], bump.inputs['Height'])
nt.links.new(bump.outputs['Normal'], p.inputs['Normal'])
# radial alpha fade (ellipse elongated along the hull)
sep = nt.nodes.new('ShaderNodeSeparateXYZ'); nt.links.new(tc.outputs['Object'], sep.inputs['Vector'])
def m_(op, a, b=None, v=None):
    n = nt.nodes.new('ShaderNodeMath'); n.operation = op
    if isinstance(a, float): n.inputs[0].default_value = a
    else: nt.links.new(a, n.inputs[0])
    if b is not None:
        if isinstance(b, float): n.inputs[1].default_value = b
        else: nt.links.new(b, n.inputs[1])
    return n.outputs[0]
dx = m_('DIVIDE', sep.outputs['X'], 13.0); dy = m_('DIVIDE', sep.outputs['Y'], 6.5)
d = m_('SQRT', m_('ADD', m_('MULTIPLY', dx, dx), m_('MULTIPLY', dy, dy)))
fade = nt.nodes.new('ShaderNodeMapRange'); fade.interpolation_type = 'SMOOTHERSTEP'
fade.inputs['From Min'].default_value = 1.0; fade.inputs['From Max'].default_value = 0.35
nt.links.new(d, fade.inputs['Value'])
# foam: near the hull outline
fx = m_('DIVIDE', sep.outputs['X'], 7.3); fy = m_('DIVIDE', sep.outputs['Y'], 2.6)
fd = m_('SQRT', m_('ADD', m_('MULTIPLY', fx, fx), m_('MULTIPLY', fy, fy)))
anillo_f = m_('MAXIMUM', m_('SUBTRACT', 1.0, m_('DIVIDE', m_('ABSOLUTE', m_('SUBTRACT', fd, 1.0)), 0.1)), 0.0)
class _F: pass
foam = _F(); foam.outputs = {'Result': anillo_f}
noi2 = nt.nodes.new('ShaderNodeTexNoise'); noi2.inputs['Scale'].default_value = 3.5; noi2.inputs['Detail'].default_value = 6
nt.links.new(tc.outputs['Object'], noi2.inputs['Vector'])
wx = m_('SUBTRACT', m_('MULTIPLY', sep.outputs['X'], -1.0), 6.6)
ancho = m_('ADD', 1.0, m_('MULTIPLY', wx, 0.32))
ay = m_('ABSOLUTE', sep.outputs['Y'])
estela = m_('MULTIPLY', m_('GREATER_THAN', wx, 0.0), m_('SUBTRACT', 1.0, m_('MINIMUM', m_('DIVIDE', ay, ancho), 1.0)))
estela = m_('MULTIPLY', estela, m_('MAXIMUM', m_('SUBTRACT', 1.0, m_('DIVIDE', wx, 9.0)), 0.0))
fm = m_('MULTIPLY', m_('MAXIMUM', foam.outputs['Result'], estela), m_('POWER', noi2.outputs['Fac'], 2.6))
fm = m_('MINIMUM', m_('MULTIPLY', fm, 2.6), 1.0)
espuma = nt.nodes.new('ShaderNodeBsdfDiffuse'); espuma.inputs['Color'].default_value = (0.85, 0.88, 0.9, 1)
mix1 = nt.nodes.new('ShaderNodeMixShader'); nt.links.new(fm, mix1.inputs['Fac'])
nt.links.new(p.outputs['BSDF'], mix1.inputs[1]); nt.links.new(espuma.outputs['BSDF'], mix1.inputs[2])
tr = nt.nodes.new('ShaderNodeBsdfTransparent')
mix2 = nt.nodes.new('ShaderNodeMixShader'); nt.links.new(fade.outputs['Result'], mix2.inputs['Fac'])
nt.links.new(tr.outputs['BSDF'], mix2.inputs[1]); nt.links.new(mix1.outputs['Shader'], mix2.inputs[2])
nt.links.new(mix2.outputs['Shader'], out.inputs['Surface'])
bpy.ops.mesh.primitive_plane_add(size=1, location=(0, 0, 0))
mar = bpy.context.active_object; mar.scale = (26, 13, 1); mar.data.materials.append(agua)
bpy.ops.object.transform_apply(scale=True)
mar.modifiers.new('sub', 'SUBSURF').subdivision_type = 'SIMPLE'

cielo(elev=30, rot=120, fuerza=0.22, sol=False)
sol = bpy.data.lights.new('sol', 'SUN'); sol.energy = 4.6; sol.angle = math.radians(1.5); sol.color = (1.0, 0.96, 0.9)
so = bpy.data.objects.new('sol', sol); bpy.context.collection.objects.link(so)
so.rotation_euler = (math.radians(40), math.radians(0), math.radians(140))

camara((15.5, 27, 10.5), (0.4, 0, 1.0), lente=50)
salida = sys.argv[sys.argv.index('--') + 1] if '--' in sys.argv else '/home/claude/shots/barco.png'
q = int(sys.argv[sys.argv.index('--') + 2]) if '--' in sys.argv else 16
w, h = (1800, 1200) if q > 32 else (750, 500)
render(salida, w, h, muestras=q)
