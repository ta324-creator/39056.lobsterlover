---
version: 1
slug: "index-html"
primary_target: "index.html"
related_targets: []
---

# Home page (propesa.org)

Scope: the public home page, one page. Visitor mode: **Persuade**.
Audience and job: buyers in Asia, Baja California fishing cooperatives, maquila clients each understand what PROPESA offers them and email or call; staff sign in (top right) to the platform.
Proof and content: confirmed facts in PRODUCT.md only; sizes in grams and 16 kg net per cooler are real product facts. Official logo and photos come from the user later.
Constraints: Spanish, usted; regions only (China continental, Hong Kong, Taiwán); no address, R.F.C., season dates, suppliers or clients; static HTML/CSS, self-hosted fonts, no libraries at runtime.
Memorable moment: the hero is the Pacific chart in brand navy, with the red air route drawing itself from Ensenada.
Unresolved: platform subdomain (link points to app.propesa.org), photos, official logo.

## Direction contract

THESIS: PROPESA's home page as a living chart and a walk through the plant: a full-screen North Pacific chart in the logo's navy where the routes to Asia are always in flight, then full-bleed photo scenes of the real plant under a dark-to-blue veil. Refuses: framed or boxed heroes, card grids, stock photos, cluttered photos, invented claims.

OWN-WORLD: The logo's colors lead: navy #0A2373 (chart ocean, veils, contact), deep navy #06164A (footer, darkest veil), logo blue #0583C3 (buttons #0472AB, rules, glows) and its light tint #5BBAEE (second line of every headline, labels on dark). Lobster red #F0604B only for routes and destination points. Dark and white sections alternate (user, 2/nov: "too much blue, add more white"): Exportación is white with the three destinations set large (its photo was removed by the user); contact is a white split section with the Ensenada chart filling the right half; audiences white with logo-blue top rules. Archivo, big condensed two-tone headlines (white + light blue). White logo on a transparent header that turns solid navy on scroll.

STORY: The visitor sees the lobster's route to Asia moving before reading a word, then walks the plant (storage, export, maquila), sees who PROPESA serves, sees the product with its sizes, and calls or writes.

FIRST VIEWPORT: (since 3/nov) a draggable 3D satellite globe with a set boundary, right of the headline; before that: full-bleed chart, no frame or box; the map drifts slowly; red routes draw on load, then white light trails fly Ensenada → Asia on a loop and Ensenada pulses. Headline (white + light-blue second line), statement and the two actions (logo-blue phone button, white outlined email) sit over open ocean on a soft navy radial veil. Hero keeps the map's 16:9 proportion on desktop. At ≤860px: chart strip on top, text stacked below; at ≤640px destinations move to a legend.

FORM: Overdrive "Living chart" (chosen by the user from three overdrive directions) on the hybrid chart-hero site; from roll seed:ebabd9cb82c6bdcb.

FINISH: unreviewed and undocumented is unfinished; this build ends with the finish review, the verdict, DESIGN.md, and every shipping raster carrying its provenance
