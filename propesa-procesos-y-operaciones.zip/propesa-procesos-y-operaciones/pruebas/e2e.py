"""Flujo completo: entrada → órdenes → empaque → embarque → cierre. Uso: python3 -I pruebas/e2e.py"""
import json,sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from recep import recibir
FIX="localStorage.clear();localStorage.setItem('propesa-kp','0');localStorage.setItem('propesa-kp','0');localStorage.setItem('propesa-v4',JSON.stringify({PK:1,BN:0,L:[],N:0,R:[],B:{},P:[],O:[],M:{},OR:[],ORc:1,E0:1,T:[],RN:120,U:[{id:1,name:'Ana Torres',email:'admin@propesa.mx',pw:'admin123',role:'admin',notify:true},{id:2,name:'Luis Meza',email:'piso@propesa.mx',pw:'piso123',role:'piso',notify:true},{id:3,name:'Dirección',email:'consulta@propesa.mx',pw:'ver123',role:'consulta',notify:false}]}))"  # usuarios SOLO para pruebas

BASE=os.environ.get('BASE','http://localhost:8765/index.html?modo=local');OUT=os.environ.get('OUT','/tmp/propesa-pruebas');os.makedirs(OUT,exist_ok=True)  # modo local: nunca toca la base real
from playwright.sync_api import sync_playwright
ABRIR = "document.querySelectorAll('details.fold').forEach(d=>FOLD[d.dataset.fold]=true);render()"  # v1.34.0: abre los plegables (tanques, notas, precio, movimientos)
errs=[];ok=[]
def chk(c,m):
    (ok if c else errs).append(m); print(('PASS ' if c else 'FAIL ')+m)
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page(viewport={'width':1180,'height':820})
    pg.on('pageerror',lambda e:errs.append('JS '+str(e)));pg.on('console',lambda m:m.type=='error' and errs.append('CONSOLE '+m.text))
    pg.goto(BASE);pg.evaluate(FIX);pg.reload()
    pg.fill('#le','admin@propesa.mx');pg.fill('#lp','admin123');pg.click('[data-a=lg]')
    pg.click('.sb [data-go=recepcion]')
    pg.click('[data-a=nf]')  # v1.42.0: la recepción es por tinas (30 por tanque); ya no hay «kg por caja en tanque»
    tx=pg.inner_text('#app');chk(pg.evaluate("V.v")=='rtin' and 'Kg por caja en tanque' not in tx and 'tinas' in tx.lower(),'Nueva recepción abre la recepción por tinas')
    pg.click('#rt_fl');pg.keyboard.type('wlrco051026a',delay=5)
    chk(pg.input_value('#rt_fl')=='WLRCO051026A','lote en mayusculas en vivo: '+pg.input_value('#rt_fl'))
    recibir(pg,'WLRCO051026A',pv='1',kz=[100,200,300,400],tank='T1')
    chk('WLRCO051026A' in pg.inner_text('#app'),'lote guardado')
    # icons
    ic=pg.evaluate("[...document.querySelectorAll('.sb .fs')].map(b=>[b.dataset.go,b.querySelector('svg').outerHTML])")
    d=dict(ic);chk(d['embarques']!=d['recepcion'] and 'currentColor' in d['recepcion'] and 'M256 384' in d['recepcion'],'Entrada lleva la langosta (blanca) y Embarque el camión')
    # orders
    def mk(etd):
        pg.click('.sb [data-go=ordenes]');pg.fill('#no_etd',etd);pg.click('[data-oa=new]')
    def addline(cli,n,city='PVG'):
        (pg.locator('[data-oa=add]').count() and pg.click('[data-oa=add]'));pg.select_option('#ol_city',city);pg.fill('#ol_n',str(n));pg.fill('#ol_z0',str(n));pg.fill('#ol_tar','0');pg.click('[data-oa=ln]')
    mk('2026-10-12');addline('HXH',3)
    tx=pg.inner_text('#app');chk('3 hieleras · 48 kg neto · 56.7 kg de peso bruto' in tx and '2138.4' not in tx,'orden: peso bruto = hieleras × (1.4 + 1.5 + 16), sin tarimas ni cartón: 56.7 kg')
    chk(abs(pg.evaluate("ST.P[0].exp")-56.7)<1e-9,'el embarque espera el mismo peso bruto que la orden (56.7 kg)')
    mk('2026-10-13');addline('ZSM',2)
    st=json.loads(pg.evaluate("localStorage.getItem('propesa-v4')"))
    chk(len(st['P'])==2,'2 embarques antes de unir: %d'%len(st['P']))
    # v1.24.0: la orden solo dice en qué embarque va y lleva al embarque; ahí se junta con antes → después y se confirma
    chk(pg.locator('[data-sh],select[id^=sh_j_]').count()==0 and 'Juntar o separar en el embarque' in pg.inner_text('#app'),'la orden ya no junta ni separa: lleva al embarque')
    pg.click('main .shp [data-go^="emb:"]');pg.wait_for_timeout(150)
    chk(pg.locator('[data-shq^="ask:join"]').count()==1,'botón «Juntar a este embarque» presente')
    chk(pg.evaluate("document.querySelector('[data-shq^=\"ask:join\"]').dataset.shq.endsWith(':'+ST.P[V.id].u)"),'«Juntar» manda el id fijo del embarque, no su lugar en la lista')
    pg.click('[data-shq^="ask:join"]');pg.wait_for_timeout(100)
    chk(len(json.loads(pg.evaluate("localStorage.getItem('propesa-v4')"))['P'])==2 and pg.locator('#shq').count()==1 and 'ASÍ QUEDA' in pg.inner_text('#shq').upper(),'antes de juntar enseña cómo queda y no cambia nada')
    pg.click('#shq [data-shq=ok]');pg.wait_for_timeout(150)
    st=json.loads(pg.evaluate("localStorage.getItem('propesa-v4')"))
    chk(len(st['P'])==1 and st['P'][0]['h']==5,'unidas: 1 embarque con 5 hieleras: %s'%[(q['n'],q['h']) for q in st['P']])
    chk(' + ' in st['P'][0]['n'],'nombre con ambas fechas: '+st['P'][0]['n'])
    # empacar A
    pg.click('.sb [data-go=empaque]')
    pg.locator('[data-go^="empacar:"]').first.click()
    chk(pg.locator('.pkrow').count()==2 or pg.locator('.pkrow').count()==3,'filas grid: %d'%pg.locator('.pkrow').count())
    n=pg.locator('.pkrow').count()
    chk(pg.locator('.evb').count()==0,'sin botones de foto en empaque')
    # error: count sin categoria
    pg.fill('#pk_c0','30');pg.click('[data-pk=addall]');pg.wait_for_timeout(100)
    chk(pg.input_value('#pk_c0')=='30','valor conservado tras error')
    pg.click('#pkr0 [data-pk^="k:"] >> nth=0')
    # v1.12.0: cada hielera se completa sola al tocar la categoría; la siguiente queda como fila 0
    pg.fill('#pk_c0','25');pg.click('#pkr0 [data-pk^="k:"] >> nth=1');pg.wait_for_timeout(100)
    pg.wait_for_timeout(100)
    st=json.loads(pg.evaluate("localStorage.getItem('propesa-v4')"))
    bx=[b for l in st['B'].values() for b in l]
    chk(len(bx)==2 and all(b['d']==0 for b in bx),'2 hieleras guardadas a la vez, d=0: %s'%bx)
    chk(pg.locator('.pkrow').count()==n-2,'filas restantes %d'%pg.locator('.pkrow').count())
    # notes
    pg.evaluate(ABRIR);pg.fill('#ntx','nota prueba');pg.click('[data-ev^=save]');chk('nota prueba' in pg.inner_text('#app'),'nota guardada en empaque')
    # embarque page
    pg.click('.sb [data-go=embarques]');pg.locator('.bp').first.click()
    t=pg.inner_text('#app');chk('Órdenes en este embarque' in t and '12/10' in t and '13/10' in t,'panel de órdenes en embarque')
    chk(pg.locator('[data-shq^="ask:sep"]').count()==2,'botones «Sacar de este embarque»')
    pg.click('[data-shq^="ask:sep"] >> nth=1');pg.wait_for_timeout(100)
    chk('embarque nuevo' in pg.inner_text('#shq'),'antes de separar enseña el embarque nuevo')
    pg.click('#shq [data-shq=ok]');pg.wait_for_timeout(150)
    st=json.loads(pg.evaluate("localStorage.getItem('propesa-v4')"))
    chk(len(st['P'])==2 and sorted(q['h'] for q in st['P'])==[2,3],'separadas: %s'%[(q['n'],q['h']) for q in st['P']])
    chk(pg.locator('.shok [data-shq=undo]').count()==1,'después de separar se puede deshacer')
    pg.click('.shok [data-shq=undo]');pg.wait_for_timeout(150)
    st=json.loads(pg.evaluate("localStorage.getItem('propesa-v4')"))
    chk(len(st['P'])==1 and st['P'][0]['h']==5,'deshacer las vuelve a juntar: %s'%[(q['n'],q['h']) for q in st['P']])
    # separar y volver a juntar desde la lista «Puedes juntar aquí»
    pg.click('[data-shq^="ask:sep"] >> nth=1');pg.click('#shq [data-shq=ok]');pg.wait_for_timeout(150)
    pg.click('.sb [data-go=embarques]');pg.locator('.bp').first.click()
    chk(pg.locator('[data-shq^="ask:join"]').count()==1,'«Puedes juntar aquí» ofrece la otra orden')
    pg.click('[data-shq^="ask:join"]');pg.click('#shq [data-shq=ok]');pg.wait_for_timeout(150)
    st=json.loads(pg.evaluate("localStorage.getItem('propesa-v4')"))
    chk(len(st['P'])==1 and st['P'][0]['h']==5,'reunidas: %s'%[(q['n'],q['h']) for q in st['P']])
    bx=[b for l in st['B'].values() for b in l];chk(all(b['d']==0 for b in bx),'hieleras siguen en d=0 tras reindexar')
    # pack the remaining and close
    pg.click('.sb [data-go=empaque]')
    for _ in range(6):
        btns=pg.locator('[data-go^="empacar:"]:has-text("Empacar"), [data-go^="empacar:"]:has-text("Seguir")')
        if btns.count()==0:break
        btns.first.click()
        rows=pg.locator('.pkrow').count()
        for r in range(rows):
            pg.fill('#pk_c0',str(20+r));pg.click('#pkr0 [data-pk^="k:"] >> nth=2');pg.wait_for_timeout(80)
        (pg.locator('[data-pk=addall]').count() and pg.click('[data-pk=addall]'));pg.wait_for_timeout(100);pg.click('.sb [data-go=empaque]')
    st=json.loads(pg.evaluate("localStorage.getItem('propesa-v4')"))
    bx=[b for l in st['B'].values() for b in l];chk(len(bx)==5,'5 hieleras totales: %d'%len(bx))
    pg.click('.sb [data-go=embarques]');pg.locator('.bp').first.click()
    chk(pg.locator('[data-zs]').count()==0 and pg.evaluate("ST.P[0].z")==[5,0,0,0,0],'las tallas del embarque vienen de las órdenes (sin casillas): '+str(pg.evaluate("ST.P[0].z")))
    # v1.9.0: hoja de empaque completa de las dos órdenes (si falta algo, cerrar pregunta)
    pg.evaluate("ST.OR.forEach(o=>{o.f={...(o.f||{}),hf:'08:00',re:'Ana Torres',ev:'S',pl:'ZRY68F3',ch:'Alejandro S.',tel:'646-294-1282',tp:'48 - 49 °F',to:'T1',tq:'T1 - 50 °F'}});save();render()")
    chk(pg.evaluate("ST.OR.every(o=>!ordTot(o)||!f6Miss(o,true).length)"),'hoja de empaque completa en las dos órdenes (hora inicial puesta sola)')
    pg.click('[data-a=cp]');pg.wait_for_timeout(200)
    st=json.loads(pg.evaluate("localStorage.getItem('propesa-v4')"))
    chk(st['P'][0]['closed'],'cerrado'); print(st['O'][0]['body'][:300]);chk('12/10' in st['O'][0]['body'] and '13/10' in st['O'][0]['body'],'correo lista ordenes')
    t=pg.inner_text('#app');chk('NaN' not in t and 'undefined' not in t,'sin NaN/undefined')
    for v in ['inicio','recepcion','ordenes','empaque','embarques','cierre']:
        pg.click(f'.sb [data-go={v}]');t=pg.inner_text('#app');chk('NaN' not in t and 'undefined' not in t,'sweep '+v)
    # old format: empacar with closed shipment hides grid
    pg.screenshot(path=OUT+'/e2e.png')
    b.close()
print('ERRS',[e for e in errs if not e.startswith(('2','3'))][:10]); sys.exit(1 if any(e.startswith(('JS','CONSOLE')) for e in errs) else 0)
