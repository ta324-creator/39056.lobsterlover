# UX.md · Cómo debe sentirse la plataforma

## 1. Para quién diseñamos

Un empleado de piso, de pie, moviéndose, con guantes o manos mojadas, con poca luz, que mira la tablet un segundo. Debe entender al instante:

1. ¿Dónde estoy?
2. ¿Qué estoy haciendo?
3. ¿Qué necesita mi atención?
4. ¿Qué ya está completo?
5. ¿Hay un problema?

El usuario lo resume así: que sea **tan fácil como la caja de McDonald's** (ver `docs/referencias/investigacion_mcdonalds.txt`).

## 2. Principios (de la investigación de McDonald's)

| Principio | En PROPESA |
|---|---|
| **Cero fricción** | Cada acción es un botón grande al frente. Nada de menús anidados ni buscar. Flujo lineal. |
| **Rejilla densa y fija** | Botones grandes en lugares que no se mueven, para crear memoria muscular. Las cajas de Modo piso tienen lugar fijo (`b.ps`). |
| **Revelación progresiva** | Solo se muestra lo del paso actual: cliente → lote → cajas. Si hay un solo lote, se salta ese paso. |
| **A prueba de errores (poka-yoke)** | El sistema no deja avanzar sin lo necesario y explica qué falta. No se pueden empacar más cajas de las pedidas, ni un conteo mayor a lo esperado. |
| **Se entiende sin leer** | Íconos + colores constantes (ROJO / VERDE / BLANCO; colores de talla) + texto corto. |

## 3. Reglas de interacción

- **Los avisos rojos llevan a donde se resuelven.** Chip, tarjeta o renglón de alerta = botón: «Faltan N · Empacar ›», «Sin líneas · Agregar ›», «Resolver ›». Si el problema es un campo, se hace scroll, se enfoca y se resalta (`data-jump`). Toda notificación nueva debe seguir esta regla.
- **Corregir tiene que ser fácil.** Una caja guardada en Modo piso se queda en pantalla, gris con ✔, y se puede editar ahí mismo o quitar (con confirmación). Nada desaparece después de guardar.
- **Se guarda solo cuando se puede.** En Modo piso cada caja se guarda al tener piezas y categoría (`peTry`), sin botón «Guardar».
- **Varias cosas a la vez.** Los empleados anotan varias cajas a la vez: se muestran todas las cajas pendientes del cliente, no una por una. «Poner a todas las vacías» aplica una categoría de un toque.
- **Los formularios no borran lo escrito** cuando hay un error: se marca el campo en rojo, se enfoca y se explica.
- **Confirmar solo lo destructivo:** quitar caja, eliminar lote, restaurar respaldo, borrar datos (este último exige escribir BORRAR).
- **El logo siempre regresa al inicio**, en cualquier modo.
- **Cambiar de modo** con un interruptor tipo iOS y una transición suave (sin animación si el equipo pide movimiento reducido).
- **Listas cortas:** solo lo abierto o reciente (lotes 30 días, órdenes y embarques 14, temperatura 7) con «Ver historial».
- **Mensajes:** un toast breve al guardar; nunca «Guardado» si el guardado falló (aviso rojo fijo con «Descargar respaldo» y «Reintentar»).

## 4. Modo piso

Pantalla de botones grandes para el Encargado de piso (entra directo); el admin lo activa con el interruptor «Modo piso».

| Botón | Flujo |
|---|---|
| **Empacar cajas** | Cliente → lote (se salta si hay uno) → una tarjeta grande por cada caja del cliente (piezas + ROJO/VERDE/BLANCO). Se guarda sola, queda gris con ✔. |
| **Registrar entrada** | Asistente: proveedor → tanque → lote y temperaturas → kilos por talla → revisar y guardar. |
| **Cerrar embarque** | Abre la pantalla normal sin menú. |
| **Conteo final** | Abre la pantalla normal sin menú. |

Estilo iOS: encabezado translúcido con desenfoque, título grande, tarjetas con degradado, cuadros de ícono, buena vista en tema oscuro.

## 5. Vista completa

- Menú lateral navy fijo en tablet y computadora; en celular se oculta y se abre con ☰. Pasos numerados con íconos.
- Barra superior: buscador, botón **Ajustes** (siempre visible, por accesibilidad) y círculo con la inicial del usuario.
- Menú del círculo: nombre, correo, rol, **Administración** (solo admin), **Cerrar sesión** y la versión. **Ajustes no se mueve al menú**: se queda en la barra.
- **Ajustes:** panel que **deja ver la pantalla de atrás** (translúcido, sin oscurecer; en celular, hoja desde abajo de máx. 66 % de alto). Tema claro/oscuro/del equipo y tamaño de texto con **deslizador de 3 tamaños** (Normal, Grande, Muy grande). Esc, ✕ o tocar fuera lo cierran; el foco regresa al botón. Abrirlo no borra lo que se estaba capturando.
- Panel: «Tu siguiente paso», totales, tablero de lotes por etapa, avance de órdenes, actividad reciente.
- En celular, las filas de Empaque se vuelven tarjetas.

## 6. Accesibilidad (mínimos)

- Lighthouse accesibilidad = 100 en las 14 pantallas (comprobar con `pruebas/accesibilidad.mjs`).
- Contraste AA; estados con ícono y texto, nunca solo color.
- Objetivos táctiles ≥ 44 px (botones 48, Modo piso ~60). Campos ≥ 16 px (evita zoom en iPhone).
- Foco visible, «Saltar al contenido», orden de títulos correcto, encabezados de tabla con texto (`aria-label` si la columna es de acciones), etiquetas en todos los campos.
- Diálogos y menús accesibles: `role`, flechas, Esc, foco atrapado y de regreso.
- Debe verse bien en 390, 820 y 1440 px y con texto de 20 px.
- Teclado numérico en tablet (`inputmode`), texto seleccionado al tocar un campo.

## 7. Lo que el usuario pidió y se mantiene

- Logo pequeño y blanco en el menú; menú navy con pasos numerados e íconos de dibujo.
- Campos blancos, flechas propias, números sin flechitas.
- Azul solo en secciones de marca; fondo y textos neutros.
- Pendientes y discrepancias en rojo llamativo, con ícono y texto. Mortalidad final no va en rojo como faltante.
- Colores de consignaciones parecidos a los originales.
- Optimizada para tablet; se adapta a computadora y celular.
- El admin **no** entra en Modo piso automáticamente.
- Un usuario no técnico debe poder usarla: textos simples, un paso a la vez.

## 8. Lo que el usuario rechazó (no repetir sin preguntar)

- Rediseño oscuro con colores semánticos y números gigantes (revertido).
- Galería de fotos en el Panel (revertida).
- Modo piso de **una caja a la vez** (quiere varias).
- Que las cajas guardadas **desaparezcan** de la pantalla.
- Que Ajustes **oscurezca o tape** la pantalla.
- Más de 3 tamaños de texto (se probó un rango 12–20 px; regresó a 3, pero con deslizador).
- Mover el botón de Ajustes al menú del perfil.
- Teclado numérico propio en Modo piso (se quitó).
- Cambiar muchas cosas sin validarlas: el equipo sintió que se trabajaba «sin rumbo».
