# ARQUITECTURA.md · Cómo está hecho el código

## 1. Panorama

| Cosa | Cómo |
|---|---|
| Archivos | **Un solo `index.html`** (~205 KB, ~1,040 líneas): HTML + CSS + JS vanilla. Sin dependencias, sin build, sin npm. |
| Datos | En el navegador (`localStorage`, clave `propesa-v4`). Funciona sin internet. |
| Despliegue | GitHub → Vercel (Framework *Other*, sin build, se sirve la raíz). `vercel.json` pone cabeceras de seguridad y caché. |
| PWA ligera | `manifest.webmanifest` + íconos para «Agregar a pantalla de inicio». Sin service worker todavía. |
| Copia suelta | `PROPESA_Plataforma_maritima.html` = el mismo `index.html`. |

**Mantener todo en un archivo** hasta que haya backend. Si algún día se divide, que sea junto con la migración a Supabase.

## 2. Ciclo de la app

```
load() ─► ST (estado global) ─► render() ─► render0() escribe #app.innerHTML
   ▲                                         │
   └── save() ◄── manejadores (data-*) ◄─────┘   go('ruta:param') cambia V y vuelve a dibujar
```

- **`ST`**: todo el estado (ver `DATOS.md`). `save()` lo serializa completo y devuelve `true/false`; si falla, `SAVE_ERR` muestra un aviso rojo fijo (`topBanners`).
- **`me`**: usuario en sesión, **solo en memoria** (recargar cierra la sesión).
- **`V = {v, id}`**: vista actual. `go('orden:3')` → `V={v:'orden',id:'3'}`; limpia estado temporal (`msg`, `form`, `conf`, `HIST`…) y hace scroll arriba.
- **`render()`** crea los índices de dibujo (`RX`) y llama a `render0()`, que decide: sin usuarios → `setupView()`; sin sesión → `loginView()`; Modo piso → `pisoShell(...)`; si no, menú + página de `PG`.
- **Plantillas de texto**: cada página es una función que devuelve HTML (`` `...${E(x)}...` ``). **Siempre `E()` para texto del usuario.**

## 3. Rutas (`PG`) y paso del menú (`STEP`)

```js
PG = { piso, pemp, pent, inicio, recepcion, lote, empaque, empacar, embarques, emb, ordenes, orden, cierre, temperatura, admin, buscar }
STEP = { recepcion:1, lote:1, ordenes:2, orden:2, empaque:3, empacar:3, embarques:4, emb:4, cierre:5 }
```

| Ruta | Parámetro | Pantalla |
|---|---|---|
| `inicio` | — | Panel |
| `recepcion` · `lote:<lote>` | código de lote | Entrada · detalle de lote |
| `ordenes` · `orden:<id>` | id de orden | Órdenes · detalle |
| `empaque` · `empacar:<orden>.<línea>` | `3.2` | Empaque · empacar un cliente |
| `embarques` · `emb:<i>` | índice en `ST.P` | Embarque · consignación |
| `cierre` | — | Mortalidad final |
| `temperatura`, `admin`, `buscar:<texto>` | | |
| `piso` · `pemp[:o.l]` · `pent` | | Modo piso: inicio, empacar, entrada |

Los nombres internos (`recepcion`, `cierre`) **no se renombran**; solo los textos visibles.

## 4. Eventos

Delegación: un manejador de clic en `document` lee atributos `data-*`; hay manejadores extra para `input`/`change`/`keydown`.

| Atributo | Para qué |
|---|---|
| `data-go="ruta"` | Navegar |
| `data-a="..."` | Acciones generales (`sv` guardar lote, `s0` crear admin, `tq` guardar temperatura, `rst` borrar datos, `lo` salir…) |
| `data-oa` | Órdenes (líneas, unir) |
| `data-pk` | Empaque en vista completa (`addall`, `del:<seq>`) |
| `data-pe` | Modo piso (`all:K`, `sk:seq:K`, `cf`/`rm`) |
| `data-row` | Filas de la tabla de cajas (**no usar `data-r`**: es el de «Revertir movimiento»; ese choque ya causó un bug grave) |
| `data-ev` | Fotos y notas |
| `data-zs` | Tallas del embarque |
| `data-sh` | Acciones de embarque |
| `data-fin` · `data-alive` | Conteo final por lote · vivas al llegar |
| `data-pdf="dl|mail:<tipo>:<arg>"` | PDF de cada paso |
| `data-jump` | Ir a un campo, enfocarlo y resaltarlo |
| `data-hist` · `data-histoff` | Abrir / cerrar historial de una lista |
| `data-bk="dl|up"` | Descargar / restaurar respaldo |
| `data-settings` · `data-setclose` | Abrir / cerrar Ajustes |
| `data-avatar` · `data-pm` · `data-pmclose` | Menú del perfil |
| `data-tqdel` | Eliminar lectura de temperatura (admin) |

Antes de agregar un `data-*` nuevo, busca que no exista ya con otro significado.

## 5. Mapa de funciones

| Área | Funciones |
|---|---|
| Núcleo | `load`, `seed`, `save`, `render`, `render0`, `go`, `E`, `toast`, `topBanners`, `iconize` |
| Formularios | `renderKeep`, `fail` (conservan lo escrito y marcan el campo) |
| Entrada / lotes | `recepcion`, `lote`, `lotForm`, `saveLot`, `newLotId`, `delLot`, `closeLot`, `post` (movimientos), `mv`, `rev` |
| Órdenes | `ordenes`, `orden`, `ordAssigned`, `ordCsv` (packing list CSV), `cleanOrders`, `seedOR` |
| Empaque | `empaque`, `empacar`, `pkGrid`, `pkCnt`, `pendChip`, `goPend`/`goLine` |
| Embarque | `embarques`, `emb`, `shipFor`, `newShip`, `syncShip`, `syncShipIdx`, `shipLinks`, `moveGroup`, `dropShip`, `joinable`, `shipPanel`, `shipIssues`, `shipAlert`, `truck`, `closeP` |
| Mortalidad | `cierre`, `calc`, `donut`, `hbars` |
| Temperatura | `temperatura`, `saveTemp` |
| Panel / búsqueda | `inicio`, `nxt` (siguiente paso), `buscar` |
| Fotos y notas | `evid`, `evDraft`, `shrink` (reduce fotos) |
| Usuarios | `setupView`, `setupSave`, `loginView`, `saveU`, `admin`, `sha256`, `pwHash`, `migrateUsers`, `can` |
| Respaldo | `cleanST` (limpia y valida un respaldo antes de usarlo) |
| PDF | `PdfRep` (escritor propio), `pdfEntrada`, `pdfOrdenes`, `pdfEmpaque`, `pdfEmbarque`, `pdfEmbarques`, `pdfMort`, `pdfMake`, `pdfSave`, `pdfMail`, `pdfBar` |
| Modo piso | `pisoShell`, `pisoHome`, `pisoEmp`, `peSlots`, `peTry`, `peRender`, `peLine`, `pisoEnt`, `penCheck`, `penSave`, `switchMode`, `setPiso` |
| Ajustes | `applyPrefs`, `savePrefs`, `settingsHTML`, `paintSettings`, `openSettings`, `closeSettings`, `syncSetBtns`, `fsSnap` |
| Menú del perfil | `avatarBtn`, `pmenuHTML`, `placePmenu`, `openPmenu`, `closePmenu`, `syncAv` |
| Listas | `histList(key, items, activoFn)` → `{items, bar}` |
| Fechas | `dLoc()` (fecha local; **no usar `toISOString()`**), `fd()` ISO → dd/mm/aaaa |

## 6. Rendimiento

Probado con un año de datos (500 lotes, 37,400 cajas, 250 órdenes y embarques) y CPU 4× más lenta (≈ tablet): Panel ~36 ms, guardar una caja en piso ~138 ms.

- **Índices de dibujo `RX`**: `render()` arma una vez por dibujo `rxLine`, `rxShip`, `rxMov`, `rxLinks`, `rxLot`, `rxRvd`; funciones como `ordAssigned`, `bal`, `calc`, `shipLinks` los usan si existen y, fuera del dibujo, calculan directo (los manejadores siempre ven datos frescos). Si agregas un cálculo que recorre todas las cajas o movimientos, **úsalo dentro de un índice**.
- **Listas activas** (`histList`, `HIST`): solo lo abierto o reciente; historial de 100 en 100.
- Pendiente: `save()` reescribe todo (~80 ms en tablet con un año); las fotos en base64 inflan el almacenamiento (mover a IndexedDB o Supabase Storage).

## 7. Ajustes y preferencias

- `PREF = {theme, fs}`; `applyPrefs()` pone `data-theme` en `<html>` y `--app-font-size`.
- Un script temprano en `<head>` (dentro de una IIFE para no chocar con variables de la app) aplica tema y tamaño antes de pintar.
- El panel vive en `#setp`, **fuera de `#app`**, para que abrirlo no redibuje ni borre lo capturado. Lo mismo el menú del perfil (`#pmenu`).

## 8. PDF

Escritor propio `PdfRep` (sin librerías): Helvetica con codificación WinAnsi y métricas reales, logo en JPEG, tablas con encabezado repetido, paginación. Cada paso tiene su barra (`pdfBar`) con **Descargar PDF** y **Enviar por correo**: Web Share con archivo en tablet/celular; si no existe, descarga + `mailto:` a los usuarios con «Recibe informes».

## 9. Claves en `localStorage`

| Clave | Contenido |
|---|---|
| `propesa-v4` | `ST` completo |
| `propesa-theme` | `light` / `dark` / sin valor (sigue al equipo) |
| `propesa-fs` | Tamaño de texto (15, 17 o 20) |
| `propesa-piso` | Preferencia de Modo piso del equipo |
| `propesa-z` | Tamaño viejo (solo se lee para migrar) |

## 10. Archivos del repositorio

```
propesa-plataforma/
├── index.html              ← toda la app
├── CLAUDE.md · AGENTS.md   ← instrucciones para asistentes de IA
├── README.md · CHANGELOG.md
├── SPEC.md · tasks/plan.md ← especificación y plan del panel de Ajustes y menú del perfil
├── docs/                   ← contexto del proyecto (este archivo y los demás)
│   └── referencias/        ← formatos en papel y documentos del usuario
├── pruebas/                ← pruebas automáticas (Playwright/Python) y datos de prueba
├── supabase/schema.sql     ← esquema preparado, NO aplicado
├── vercel.json · manifest.webmanifest · íconos
└── .claude/settings.json   ← activa el plugin agent-skills en Claude Code
```
